                                                                <?php
$con=mysqli_connect("localhost","root", "", "live_gallery");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

if ($_POST['firstname']=='' or $_POST['lastname']=='' or $_POST['phone']=='' or $_POST['college']=='' or $_POST['dept']=='' or $_POST['password']=='' or $_POST['email']=='' or $_POST['accom']==NULL) {
	echo 0;
	return;
	}

if (!isset($_POST['firstname']) || !isset($_POST['lastname']) || !isset($_POST['phone']) || !isset($_POST['college']) || !isset($_POST['dept']) || !isset($_POST['password']) || !isset($_POST['email']) || !isset($_POST['accom'])) {
	echo 0;
	return;
	}

else {

//validating email	
if (isset($_POST['email'])) {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo 0;
            return;
            }
        }

	$firstname = stripslashes($_POST['firstname']);
	$lastname = stripslashes($_POST['lastname']);
	$phone = stripslashes($_POST['phone']);
	$college = stripslashes($_POST['college']);
	$dept= stripslashes($_POST['dept']);
	$password = stripslashes($_POST['password']);
	$accom = stripslashes($_POST['accom']);
	$fbid = stripslashes($_POST['fbid']);

	$sql = "SELECT * FROM User WHERE email = '$email'";
	$result = mysqli_query($con,$sql);
	$num_rows=mysqli_num_rows($result);
	if($num_rows) { 
		echo 2;
		return;
	}				


	$sql="INSERT INTO User (firstname,lastname,phone,college,dept,password,email,accom,fbid) VALUES ('$firstname', '$lastname','$phone','$college','$dept','$password','$email','$accom','$fbid')";

	if (!mysqli_query($con,$sql)) {
	  echo 0;
	  die('Error: ' . mysqli_error($con));
	}
	echo 1;
	}
?>

                            
                            